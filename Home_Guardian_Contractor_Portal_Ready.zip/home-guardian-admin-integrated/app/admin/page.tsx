'use client';
import {useCallback,useEffect,useState} from 'react';
import {createClient, type Session} from '@supabase/supabase-js';
type Metrics={members:number;activeMembers:number;contractors:number;pendingContractors:number;requests:number;openRequests:number;assignedRequests:number};
type Contractor={user_id:string;approved:boolean;trade:string;service_area:string};
type History={id:number;request_id:number;contractor_id:string;action:string;actor_id:string;occurred_at:string};
type Audit={id:number;actor_id:string;action:string;target_type:string;target_id:string;occurred_at:string};
type Job={id:number;trade:string;description:string;status:string;service_area:string;repair_assignments:{contractor_id:string}|null};
export default function AdminPage(){
 const [email,setEmail]=useState(''),[password,setPassword]=useState(''),[loginBusy,setLoginBusy]=useState(false),[token,setToken]=useState(''),[history,setHistory]=useState<History[]>([]),[audits,setAudits]=useState<Audit[]>([]),[metrics,setMetrics]=useState<Metrics|null>(null),[contractors,setContractors]=useState<Contractor[]>([]),[jobs,setJobs]=useState<Job[]>([]),[page,setPage]=useState(1),[total,setTotal]=useState(0),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 const [authClient]=useState(()=>createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,{auth:{persistSession:true,autoRefreshToken:true}}));
 useEffect(()=>{let mounted=true;authClient.auth.getSession().then(({data})=>{if(mounted)setToken(data.session?.access_token||'')});const {data:{subscription}}=authClient.auth.onAuthStateChange((_event,session:Session|null)=>{if(mounted)setToken(session?.access_token||'')});return()=>{mounted=false;subscription.unsubscribe()}},[authClient]);
 async function login(e:React.FormEvent){e.preventDefault();setError('');setLoginBusy(true);try{const {error}=await authClient.auth.signInWithPassword({email,password});if(error)throw error;setPassword('')}catch(e){setError(e instanceof Error?e.message:'Sign-in failed')}finally{setLoginBusy(false)}}
 async function logout(){await authClient.auth.signOut();setMetrics(null);setContractors([]);setJobs([]);setHistory([]);setAudits([])}
 const call=useCallback(async(path:string,options:RequestInit={})=>{
  const res=await fetch(path,{...options,headers:{'Authorization':`Bearer ${token}`,'Content-Type':'application/json',...(options.headers||{})},cache:'no-store'});
  const data=await res.json();if(!res.ok)throw Error(data.error||'Request failed');return data;
 },[token]);
 const refresh=useCallback(async()=>{
  if(!token)return;
  setBusy(true);setError('');
  try{
   const [overview,c,j,h,a]=await Promise.all([call('/api/admin/overview'),call('/api/admin/contractors?page='+page),call('/api/admin/requests?page='+page),call('/api/admin/history?page='+page),call('/api/admin/audit?page='+page)]);
   setMetrics(overview.metrics);setContractors(c.items);setJobs(j.items);setHistory(h.items);setAudits(a.items);setTotal(Math.max(c.total,j.total,h.total,a.total));
  }catch(e){setError(e instanceof Error?e.message:'Unable to load dashboard')}finally{setBusy(false)}
 },[call,page,token]);
 useEffect(()=>{void refresh()},[refresh]);
 async function approve(id:string,approved:boolean){try{await call('/api/admin/contractors',{method:'PATCH',body:JSON.stringify({contractorId:id,approved})});await refresh()}catch(e){setError(String(e))}}
 async function reopen(id:number){if(!confirm('Reopen this work order? The assigned contractor will lose messaging access.'))return;try{const result=await call('/api/admin/reopen',{method:'POST',body:JSON.stringify({requestId:id})});alert(`${result.inAppAlertsCreated} contractor in-app alerts created`);await refresh()}catch(e){setError(String(e))}}
 const card=(label:string,value:number|undefined)=><div style={{padding:20,border:'1px solid #ccd5e2',borderRadius:12,background:'white'}}><small>{label}</small><h2>{value??'—'}</h2></div>;
 return <main style={{maxWidth:1120,margin:'auto',padding:24,fontFamily:'Arial,sans-serif',color:'#18304c'}}>
  <h1>Home Guardian Management</h1><p>Secure operations dashboard · 1,500-member launch target</p>
  {!token?<form onSubmit={e=>void login(e)} style={{display:'grid',gap:10,maxWidth:420}}>
   <label>Administrator email<input type="email" autoComplete="username" required value={email} onChange={e=>setEmail(e.target.value)} style={{width:'100%',padding:12}}/></label>
   <label>Password<input type="password" autoComplete="current-password" required value={password} onChange={e=>setPassword(e.target.value)} style={{width:'100%',padding:12}}/></label>
   <button disabled={loginBusy} type="submit">{loginBusy?'Signing in…':'Sign in securely'}</button>
   <p style={{fontSize:13}}>Only accounts listed in the Home Guardian administrator table can access management data. Use a unique administrator password and enable MFA before launch.</p>
  </form>:<div style={{display:'flex',gap:12}}><button disabled={busy} onClick={()=>void refresh()}>Refresh dashboard</button><button onClick={()=>void logout()}>Sign out</button></div>}
  {error&&<p role="alert" style={{color:'#b42318'}}>{error}</p>}
  {token&&<><section style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))',gap:12,marginTop:24}}>
   {card('Total members',metrics?.members)}{card('Active paid members',metrics?.activeMembers)}{card('Approved + pending contractors',metrics?.contractors)}{card('Pending approval',metrics?.pendingContractors)}{card('Open work orders',metrics?.openRequests)}{card('Assigned work orders',metrics?.assignedRequests)}
  </section>
  <h2>Contractor approvals</h2>
  <div style={{overflowX:'auto'}}><table style={{width:'100%',textAlign:'left'}}><thead><tr><th>Contractor ID</th><th>Trade</th><th>Service area</th><th>Status</th><th>Action</th></tr></thead><tbody>
  {contractors.map(c=><tr key={c.user_id}><td>{c.user_id.slice(0,8)}…</td><td>{c.trade}</td><td>{c.service_area}</td><td>{c.approved?'Approved':'Pending'}</td><td><button onClick={()=>void approve(c.user_id,!c.approved)}>{c.approved?'Suspend':'Approve'}</button></td></tr>)}
  </tbody></table></div>
  <h2>Work orders</h2>
  <div style={{overflowX:'auto'}}><table style={{width:'100%',textAlign:'left'}}><thead><tr><th>Order</th><th>Trade</th><th>Area</th><th>Status</th><th>Assigned contractor</th><th>Action</th></tr></thead><tbody>
  {jobs.map(j=><tr key={j.id}><td>#{j.id}</td><td>{j.trade}</td><td>{j.service_area}</td><td>{j.status}</td><td>{j.repair_assignments?.contractor_id.slice(0,8)??'—'}</td><td>{j.status==='assigned'&&<button onClick={()=>void reopen(j.id)}>Reopen & notify</button>}</td></tr>)}
  </tbody></table></div>
  <h2>Contractor acceptance and decline history</h2>
  <div style={{overflowX:'auto'}}><table style={{width:'100%',textAlign:'left'}}><thead><tr><th>When</th><th>Work order</th><th>Contractor</th><th>Decision</th></tr></thead><tbody>{history.map(h=><tr key={h.id}><td>{new Date(h.occurred_at).toLocaleString()}</td><td>#{h.request_id}</td><td>{h.contractor_id.slice(0,8)}…</td><td>{h.action}</td></tr>)}</tbody></table></div>
  <h2>Administrative audit log</h2>
  <div style={{overflowX:'auto'}}><table style={{width:'100%',textAlign:'left'}}><thead><tr><th>When</th><th>Administrator</th><th>Action</th><th>Target</th></tr></thead><tbody>{audits.map(a=><tr key={a.id}><td>{new Date(a.occurred_at).toLocaleString()}</td><td>{a.actor_id.slice(0,8)}…</td><td>{a.action}</td><td>{a.target_type}: {a.target_id.slice(0,12)}</td></tr>)}</tbody></table></div>
  <div style={{display:'flex',gap:12,marginTop:18}}><button disabled={page<=1} onClick={()=>setPage(p=>p-1)}>Previous</button><span>Page {page}</span><button disabled={page*25>=total} onClick={()=>setPage(p=>p+1)}>Next</button></div>
 </>}</main>
}
