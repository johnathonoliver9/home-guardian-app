'use client';
import {useCallback,useEffect,useState} from 'react';
import {createClient, type Session} from '@supabase/supabase-js';

type Contractor={approved:boolean;trade:string;service_area:string};
type Job={id:number;trade:string;description:string;status:string;created_at:string;service_area?:string};
type Assignment={request_id:number;assigned_at:string;request:Job};
type Alert={id:number;request_id:number;event_type:string;created_at:string;read_at:string|null};
type Message={id:number;sender_id:string;body:string;created_at:string};
const auth=createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,{auth:{persistSession:true,autoRefreshToken:true}});
const panel:React.CSSProperties={background:'#fff',borderRadius:14,padding:20,marginTop:18,boxShadow:'0 2px 12px #12263d12'};
const action:React.CSSProperties={background:'#174b79',color:'white',padding:'10px 15px',border:0,borderRadius:8,cursor:'pointer',marginRight:8,marginTop:8};
export default function ContractorPage(){
 const [session,setSession]=useState<Session|null>(null),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
 const [profile,setProfile]=useState<Contractor|null>(null),[opportunities,setOpportunities]=useState<Job[]>([]),[assignments,setAssignments]=useState<Assignment[]>([]),[alerts,setAlerts]=useState<Alert[]>([]);
 const [selected,setSelected]=useState<number|null>(null),[messages,setMessages]=useState<Message[]>([]),[draft,setDraft]=useState('');
 useEffect(()=>{let active=true;auth.auth.getSession().then(({data})=>{if(active)setSession(data.session)});const {data:{subscription}}=auth.auth.onAuthStateChange((_event,s)=>{if(active)setSession(s)});return()=>{active=false;subscription.unsubscribe()}},[]);
 const api=useCallback(async(path:string,method='GET',body?:unknown)=>{
  const {data:{session:current},error:sessionError}=await auth.auth.getSession();if(sessionError||!current)throw Error('Please sign in again');
  const response=await fetch('/api/'+path,{method,headers:{Authorization:`Bearer ${current.access_token}`,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined,cache:'no-store'});
  const result=await response.json();if(!response.ok)throw Error(result.error||'Request failed');return result;
 },[]);
 const refresh=useCallback(async()=>{
  setError('');try{
   const p=await api('contractor/profile');setProfile(p.contractor);
   if(!p.contractor.approved){setOpportunities([]);setAssignments([]);setAlerts([]);return}
   const [o,a,n]=await Promise.all([api('contractor/opportunities'),api('contractor/assignments'),api('contractor/alerts')]);
   setOpportunities(o.opportunities||[]);setAssignments(a.assignments||[]);setAlerts(n.alerts||[]);
  }catch(e){setError(e instanceof Error?e.message:'Unable to load dashboard')}
 },[api]);
 useEffect(()=>{if(session){void refresh()}else{setProfile(null);setOpportunities([]);setAssignments([]);setMessages([]);setSelected(null)}},[session?.user.id,refresh]);
 async function perform(work:()=>Promise<void>){setBusy(true);setError('');setNotice('');try{await work()}catch(e){setError(e instanceof Error?e.message:'Unexpected error')}finally{setBusy(false)}}
 async function openMessages(id:number){await perform(async()=>{const result=await api(`requests/${id}/messages`);setSelected(id);setMessages(result.messages||[])})}
 async function claim(id:number){await perform(async()=>{await api('contractor/claim','POST',{requestId:id});setNotice(`Work order #${id} accepted`);await refresh()})}
 async function decline(id:number){if(!window.confirm(`Decline work order #${id}? You will lose access to its messages and it will become available to other contractors.`))return;await perform(async()=>{await api('contractor/reopen','POST',{requestId:id});if(selected===id){setSelected(null);setMessages([])}setNotice(`Work order #${id} declined and reopened`);await refresh()})}
 async function send(){if(!selected||!draft.trim())return;await perform(async()=>{await api(`requests/${selected}/messages`,'POST',{message:draft.trim()});setDraft('');const result=await api(`requests/${selected}/messages`);setMessages(result.messages||[]);setNotice('Message sent')})}
 return <main style={{maxWidth:1020,margin:'auto',padding:'24px 16px',color:'#182b3e',fontFamily:'Arial, sans-serif'}}>
  <header style={{background:'#123b61',color:'white',padding:24,borderRadius:14}}><h1 style={{margin:'0 0 6px'}}>Home Guardian | Contractor Portal</h1><div>Job opportunities, assignments and secure homeowner messages</div></header>
  {!session?<section style={panel}><h2>Contractor sign in</h2><p>Use the email and password for your approved Home Guardian contractor account.</p><form onSubmit={e=>{e.preventDefault();void perform(async()=>{const {error}=await auth.auth.signInWithPassword({email,password});if(error)throw error;setPassword('')})}}><label style={{display:'block',marginBottom:12}}>Email<br/><input required type="email" autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} style={{padding:10,width:'min(100%,360px)'}}/></label><label>Password<br/><input required type="password" autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)} style={{padding:10,width:'min(100%,360px)'}}/></label><div><button style={action} disabled={busy}>Sign in</button></div></form></section>:
  <><section style={panel}><div style={{display:'flex',justifyContent:'space-between',alignItems:'center',flexWrap:'wrap',gap:10}}><div><h2 style={{marginBottom:4}}>Contractor dashboard</h2><span>{session.user.email}</span>{profile&&<p>Trade: <b>{profile.trade}</b> | Service area: <b>{profile.service_area}</b> | {profile.approved?'Approved':'Awaiting approval'}</p>}</div><div><button style={action} disabled={busy} onClick={()=>void refresh()}>Refresh jobs</button><button style={{...action,background:'#526273'}} onClick={()=>void auth.auth.signOut()}>Sign out</button></div></div></section>
  {profile?.approved?<><section style={panel}><h2>Available jobs ({opportunities.length})</h2><p>Only jobs matching your approved trade and service area appear here. A job can be claimed by only one contractor.</p>{!opportunities.length&&<p>No available jobs at this time.</p>}{opportunities.map(j=><article key={j.id} style={{padding:'14px 0',borderTop:'1px solid #e4e8ed'}}><b>Work order #{j.id} · {j.trade}</b><p style={{whiteSpace:'pre-wrap'}}>{j.description}</p><small>Requested {new Date(j.created_at).toLocaleString()}</small><div><button disabled={busy} style={action} onClick={()=>void claim(j.id)}>Accept job</button></div></article>)}</section>
  <section style={panel}><h2>My assigned jobs ({assignments.length})</h2>{!assignments.length&&<p>You have no active assignments.</p>}{assignments.map(a=><article key={a.request_id} style={{padding:'14px 0',borderTop:'1px solid #e4e8ed'}}><b>Work order #{a.request_id} · {a.request.trade}</b><p style={{whiteSpace:'pre-wrap'}}>{a.request.description}</p><small>Status: {a.request.status} · Assigned {new Date(a.assigned_at).toLocaleString()}</small><div><button disabled={busy} style={action} onClick={()=>void openMessages(a.request_id)}>Message homeowner</button><button disabled={busy} style={{...action,background:'#8a3838'}} onClick={()=>void decline(a.request_id)}>Decline assignment</button></div></article>)}</section>
  <section style={panel}><h2>Homeowner messages {selected?`· Work order #${selected}`:''}</h2>{selected?<><div aria-live="polite" style={{maxHeight:330,overflowY:'auto',background:'#f3f6f9',padding:14,borderRadius:8}}>{!messages.length&&<p>No messages yet.</p>}{messages.map((m,i)=><div key={m.id??i} style={{padding:10,marginBottom:8,background:'white',borderRadius:8}}><small>{m.sender_id===session.user.id?'You':'Homeowner'} · {new Date(m.created_at).toLocaleString()}</small><p style={{whiteSpace:'pre-wrap',overflowWrap:'anywhere',marginBottom:0}}>{m.body}</p></div>)}</div><label style={{display:'block',marginTop:12}}>Your message<textarea maxLength={2000} rows={3} value={draft} onChange={e=>setDraft(e.target.value)} style={{display:'block',width:'100%',boxSizing:'border-box',padding:10,marginTop:6}}/></label><button style={action} disabled={busy||!draft.trim()} onClick={()=>void send()}>Send message</button><button style={{...action,background:'#526273'}} disabled={busy} onClick={()=>void openMessages(selected)}>Refresh messages</button></>:<p>Select an assigned job to view or send secure messages.</p>}</section>
  <section style={panel}><h2>Job alerts ({alerts.length})</h2>{!alerts.length&&<p>No alerts yet.</p>}{alerts.map(a=><p key={a.id} style={{borderTop:'1px solid #e4e8ed',paddingTop:10}}>Work order #{a.request_id} · {a.event_type} <small>({new Date(a.created_at).toLocaleString()})</small></p>)}</section></>:profile?<section style={panel}><h2>Approval pending</h2><p>Home Guardian management must approve your contractor profile before you can access jobs.</p></section>:null}</>}
  {error&&<p role="alert" style={{color:'#a42323',padding:12}}>{error}</p>}{notice&&<p role="status" style={{color:'#17623d',padding:12}}>{notice}</p>}
 </main>;
}
