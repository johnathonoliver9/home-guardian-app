import {db} from '../../../../lib/server';
export async function GET(req:Request){
 if(!process.env.CRON_SECRET||req.headers.get('authorization')!==`Bearer ${process.env.CRON_SECRET}`)return new Response('Unauthorized',{status:401});
 if(!process.env.RESEND_API_KEY||!process.env.NOTIFICATION_FROM_EMAIL)return Response.json({error:'Email provider not configured'},{status:503});
 const client=db();
 const {data:batch,error}=await client.rpc('lease_notification_batch',{p_limit:40});
 if(error)return Response.json({error:'Could not lease notification batch'},{status:500});
 let sent=0,failed=0;
 for(const job of batch||[]){
  try{
   // Resolve email from trusted Auth database, not contractor-controlled profile text.
   const {data:user,error:lookupError}=await client.auth.admin.getUserById(job.recipient_id);
   if(lookupError||!user?.user?.email)throw new Error('Recipient email unavailable');
   const res=await fetch('https://api.resend.com/emails',{method:'POST',headers:{
    Authorization:`Bearer ${process.env.RESEND_API_KEY}`,'Content-Type':'application/json',
    'Idempotency-Key':job.event_key
   },body:JSON.stringify({from:process.env.NOTIFICATION_FROM_EMAIL,to:[user.user.email],subject:job.subject,text:job.body})});
   if(!res.ok)throw new Error(`Provider returned ${res.status}`);
   await client.from('notification_outbox').update({status:'sent',delivered_at:new Date().toISOString(),lease_until:null,last_error:null}).eq('id',job.id).eq('status','processing').eq('attempts',job.attempts);
   sent++;
  }catch(e){
   const attempts=Number(job.attempts);
   const backoffMinutes=Math.min(360,Math.pow(2,attempts));
   await client.from('notification_outbox').update({
    status:attempts>=8?'failed':'pending',lease_until:null,
    next_attempt_at:new Date(Date.now()+backoffMinutes*60000).toISOString(),
    last_error:String(e).slice(0,200)
   }).eq('id',job.id).eq('status','processing').eq('attempts',job.attempts);
   failed++;
  }
 }
 return Response.json({leased:(batch||[]).length,sent,failed});
}
