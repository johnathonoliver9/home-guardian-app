import {db} from '../../../../lib/server';
export async function GET(req:Request){if(!process.env.CRON_SECRET||req.headers.get('authorization')!==`Bearer ${process.env.CRON_SECRET}`)return new Response('Unauthorized',{status:401});
 const today=new Date().toISOString().slice(0,10);const soon=new Date(Date.now()+7*86400000).toISOString().slice(0,10);
 const {data:tasks,error}=await db().from('maintenance_tasks').select('id,user_id,title,next_due').lte('next_due',soon).limit(1000);
 if(error)return Response.json({error:error.message},{status:500});let count=0;
 for(const task of tasks||[]){const {data:m}=await db().from('memberships').select('status,paid_through').eq('user_id',task.user_id).maybeSingle();if(!m||!['active','trialing'].includes(m.status)||!m.paid_through||new Date(m.paid_through)<=new Date())continue;
 const days=Math.round((Date.parse(task.next_due)-Date.parse(today))/86400000);const title=days<0?'Overdue maintenance':days===0?'Maintenance due today':'Upcoming maintenance';
 const {error:e}=await db().from('notifications').upsert({user_id:task.user_id,task_id:task.id,reminder_date:today,title,body:`${task.title}: ${days<0?'overdue':days===0?'due today':`due in ${days} days`}.`},{onConflict:'task_id,reminder_date'});if(!e)count++;
 }
 return Response.json({processed:count});}
