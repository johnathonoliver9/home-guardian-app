import {currentUser,db,unauthorized} from '../../../../lib/server';
export async function GET(req:Request){
 const user=await currentUser(req);if(!user)return unauthorized();
 const {data,error}=await db().from('contractors').select('user_id,approved,trade,service_area').eq('user_id',user.id).maybeSingle();
 if(error)return Response.json({error:'Unable to load contractor profile'},{status:500});
 if(!data)return Response.json({error:'No contractor profile found. Contact Home Guardian management for onboarding.'},{status:403});
 return Response.json({contractor:data},{headers:{'Cache-Control':'no-store'}});
}
