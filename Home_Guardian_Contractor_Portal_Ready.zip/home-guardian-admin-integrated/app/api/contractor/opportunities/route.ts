import {currentUser,db,unauthorized} from '../../../../lib/server';
export async function GET(req:Request){
 const user=await currentUser(req);if(!user)return unauthorized();
 const database=db();
 const {data:contractor,error:ce}=await database.from('contractors').select('approved,trade,service_area').eq('user_id',user.id).maybeSingle();
 if(ce)return Response.json({error:'Database error'},{status:500});
 if(!contractor?.approved)return Response.json({error:'Approved contractor required'},{status:403});
 const {data,error}=await database.from('repair_requests').select('id,trade,description,created_at,status').eq('status','open').eq('trade',contractor.trade).eq('service_area',contractor.service_area).order('created_at',{ascending:false}).limit(50);
 if(error)return Response.json({error:'Database error'},{status:500});
 // Do not expose homeowner contact details or identity in public opportunities.
 return Response.json({opportunities:data});
}
