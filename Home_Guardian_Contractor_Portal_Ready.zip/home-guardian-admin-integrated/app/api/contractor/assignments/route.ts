import {currentUser,db,unauthorized} from '../../../../lib/server';
export async function GET(req:Request){
 const user=await currentUser(req);if(!user)return unauthorized();
 const database=db();
 const {data:contractor,error:ce}=await database.from('contractors').select('approved').eq('user_id',user.id).maybeSingle();
 if(ce)return Response.json({error:'Unable to verify contractor'},{status:500});
 if(!contractor?.approved)return Response.json({error:'Approved contractor required'},{status:403});
 const {data:assignments,error}=await database.from('repair_assignments').select('request_id,assigned_at').eq('contractor_id',user.id).order('assigned_at',{ascending:false}).limit(100);
 if(error)return Response.json({error:'Unable to load assignments'},{status:500});
 const ids=(assignments||[]).map(a=>a.request_id);
 if(!ids.length)return Response.json({assignments:[]},{headers:{'Cache-Control':'no-store'}});
 const {data:requests,error:re}=await database.from('repair_requests').select('id,trade,description,status,created_at,service_area').in('id',ids);
 if(re)return Response.json({error:'Unable to load work orders'},{status:500});
 const byId=new Map((requests||[]).map(r=>[r.id,r]));
 return Response.json({assignments:(assignments||[]).map(a=>({...a,request:byId.get(a.request_id)||null})).filter(a=>a.request)},{headers:{'Cache-Control':'no-store'}});
}
