import {currentUser,db,unauthorized} from '../../../../lib/server';
export async function POST(req:Request){
 const user=await currentUser(req);if(!user)return unauthorized();
 const body=await req.json().catch(()=>null);
 if(!Number.isSafeInteger(body?.requestId)||body.requestId<1)return Response.json({error:'Invalid request ID'},{status:400});
 const {data,error}=await db().rpc('claim_repair',{p_request_id:body.requestId,p_contractor_id:user.id});
 if(error)return Response.json({error:'Assignment failed'},{status:500});
 if(!data)return Response.json({error:'Request unavailable, already assigned, or contractor ineligible'},{status:409});
 return Response.json({assigned:true,requestId:body.requestId});
}
