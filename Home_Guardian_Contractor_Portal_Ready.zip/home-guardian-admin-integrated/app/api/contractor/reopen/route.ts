import {currentUser,db,unauthorized} from '../../../../lib/server';
export async function POST(req:Request){
 const user=await currentUser(req);if(!user)return unauthorized();
 const body=await req.json().catch(()=>null);
 if(!Number.isSafeInteger(body?.requestId)||body.requestId<1)return Response.json({error:'Invalid request ID'},{status:400});
 const {data,error}=await db().rpc('reopen_repair',{p_request_id:body.requestId,p_actor_id:user.id});
 if(error)return Response.json({error:'Not authorized or request unavailable'},{status:409});
 return Response.json({reopened:true,contractorsNotifiedInApp:data});
}
