import {currentUser,db,unauthorized} from '../../../../lib/server';
export async function GET(req:Request){
 const user=await currentUser(req);if(!user)return unauthorized();
 const {data,error}=await db().from('contractor_alerts').select('id,request_id,event_type,created_at,read_at').eq('contractor_id',user.id).order('created_at',{ascending:false}).limit(50);
 if(error)return Response.json({error:'Database error'},{status:500});
 return Response.json({alerts:data});
}
