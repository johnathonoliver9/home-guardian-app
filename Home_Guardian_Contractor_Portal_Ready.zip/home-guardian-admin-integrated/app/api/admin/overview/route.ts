import {requireAdmin} from '../../../../lib/admin';
import {db} from '../../../../lib/server';
export async function GET(req:Request){
 const auth=await requireAdmin(req);if(auth.error)return auth.error;
 const client=db();
 const [members,active,contractors,pending,requests,open,assigned,recent]=await Promise.all([
  client.from('memberships').select('*',{count:'exact',head:true}),
  client.from('memberships').select('*',{count:'exact',head:true}).in('status',['active','trialing']).gt('paid_through',new Date().toISOString()),
  client.from('contractors').select('*',{count:'exact',head:true}),
  client.from('contractors').select('*',{count:'exact',head:true}).eq('approved',false),
  client.from('repair_requests').select('*',{count:'exact',head:true}),
  client.from('repair_requests').select('*',{count:'exact',head:true}).eq('status','open'),
  client.from('repair_requests').select('*',{count:'exact',head:true}).eq('status','assigned'),
  client.from('repair_requests').select('id,trade,service_area,status,created_at').order('created_at',{ascending:false}).limit(15)
 ]);
 const failures=[members,active,contractors,pending,requests,open,assigned,recent].filter(x=>x.error);
 if(failures.length)return Response.json({error:'Unable to load dashboard'},{status:500});
 return Response.json({metrics:{members:members.count,activeMembers:active.count,contractors:contractors.count,pendingContractors:pending.count,requests:requests.count,openRequests:open.count,assignedRequests:assigned.count},recentRequests:recent.data},{headers:{'Cache-Control':'no-store'}});
}
