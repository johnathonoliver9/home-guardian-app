import {requireAdmin} from '../../../../lib/admin';
import {db} from '../../../../lib/server';
export async function GET(req:Request){
 const auth=await requireAdmin(req);if(auth.error)return auth.error;
 const page=Math.max(1,Math.min(10000,Number(new URL(req.url).searchParams.get('page'))||1));
 const {data,error,count}=await db().from('contractors').select('user_id,approved,trade,service_area,created_at',{count:'exact'}).order('created_at',{ascending:false}).range((page-1)*25,page*25-1);
 if(error)return Response.json({error:'Unable to list contractors'},{status:500});
 return Response.json({items:data,total:count,page},{headers:{'Cache-Control':'no-store'}});
}
export async function PATCH(req:Request){
 const auth=await requireAdmin(req);if(auth.error)return auth.error;
 const body=await req.json().catch(()=>null);
 if(!body||typeof body.contractorId!=='string'||typeof body.approved!=='boolean'||!/^[0-9a-f-]{36}$/i.test(body.contractorId))return Response.json({error:'Invalid request'},{status:400});
 const {data,error}=await db().rpc('set_contractor_approval',{p_actor_id:auth.user!.id,p_contractor_id:body.contractorId,p_approved:body.approved});
 if(error)return Response.json({error:'Approval change failed'},{status:409});
 if(!data)return Response.json({error:'Contractor not found'},{status:404});
 return Response.json({updated:true});
}
