import {requireAdmin} from '../../../../lib/admin';
import {db} from '../../../../lib/server';
export async function GET(req:Request){
 const auth=await requireAdmin(req);if(auth.error)return auth.error;
 const url=new URL(req.url),page=Math.max(1,Number(url.searchParams.get('page'))||1),status=url.searchParams.get('status');
 if(page>10000||status&&!['open','assigned'].includes(status))return Response.json({error:'Invalid filters'},{status:400});
 let query=db().from('repair_requests').select('id,trade,description,status,service_area,created_at,repair_assignments(contractor_id,assigned_at)',{count:'exact'});
 if(status)query=query.eq('status',status);
 const {data,error,count}=await query.order('created_at',{ascending:false}).range((page-1)*25,page*25-1);
 if(error)return Response.json({error:'Unable to list requests'},{status:500});
 return Response.json({items:data,total:count,page},{headers:{'Cache-Control':'no-store'}});
}
