import {requireAdmin} from '../../../../lib/admin';
import {db} from '../../../../lib/server';
export async function GET(req:Request){
 const auth=await requireAdmin(req);if(auth.error)return auth.error;
 const page=Math.max(1,Math.min(10000,Number(new URL(req.url).searchParams.get('page'))||1));
 const {data,error,count}=await db().from('contractor_assignment_history').select('id,request_id,contractor_id,action,actor_id,occurred_at',{count:'exact'}).order('occurred_at',{ascending:false}).range((page-1)*25,page*25-1);
 if(error)return Response.json({error:'Unable to load history'},{status:500});
 return Response.json({items:data,total:count,page},{headers:{'Cache-Control':'no-store'}});
}
