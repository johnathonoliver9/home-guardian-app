import {currentUser,db,unauthorized} from '../../../../../lib/server';
function validId(value:string){const id=Number(value);return Number.isSafeInteger(id)&&id>0?id:null}
export async function GET(req:Request,{params}:{params:Promise<{id:string}>}){
 const user=await currentUser(req);if(!user)return unauthorized();
 const id=validId((await params).id);if(!id)return Response.json({error:'Invalid ID'},{status:400});
 const {data,error}=await db().rpc('read_repair_messages',{p_request_id:id,p_reader_id:user.id,p_limit:100});
 if(error)return Response.json({error:'Access denied or assignment changed'},{status:403});
 return Response.json({messages:[...(data||[])].reverse()},{headers:{'Cache-Control':'no-store'}});
}
export async function POST(req:Request,{params}:{params:Promise<{id:string}>}){
 const user=await currentUser(req);if(!user)return unauthorized();
 const id=validId((await params).id);if(!id)return Response.json({error:'Invalid ID'},{status:400});
 const body=await req.json().catch(()=>null);
 if(typeof body?.message!=='string'||!body.message.trim()||body.message.length>2000)return Response.json({error:'Invalid message'},{status:400});
 const {data,error}=await db().rpc('send_repair_message',{p_request_id:id,p_sender_id:user.id,p_body:body.message.trim()});
 if(error)return Response.json({error:'Access denied or assignment changed'},{status:409});
 return Response.json({id:data},{status:201});
}
