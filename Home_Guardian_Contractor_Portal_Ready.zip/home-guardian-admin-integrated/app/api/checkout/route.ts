import {currentUser,stripe,unauthorized} from '../../../lib/server';
export async function POST(req:Request){
 const user=await currentUser(req);if(!user)return unauthorized();
 const {plan}=await req.json();if(plan!=='monthly'&&plan!=='annual')return Response.json({error:'Invalid plan'},{status:400});
 const price=plan==='annual'?process.env.STRIPE_ANNUAL_PRICE_ID:process.env.STRIPE_MONTHLY_PRICE_ID;
 if(!price)return Response.json({error:'Price not configured'},{status:500});
 const session=await stripe().checkout.sessions.create({mode:'subscription',customer_email:user.email,client_reference_id:user.id,line_items:[{price,quantity:1}],subscription_data:{metadata:{user_id:user.id,plan}},success_url:`${process.env.APP_URL}/?checkout=success`,cancel_url:`${process.env.APP_URL}/?checkout=cancel`});
 return Response.json({url:session.url});
}
