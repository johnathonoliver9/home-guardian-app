// Run against a disposable Supabase/Postgres test database only.
// DATABASE_URL must be a Postgres connection string with rights to create test fixtures.
import test from 'node:test';
import assert from 'node:assert/strict';
import pg from 'pg';
const {Pool}=pg;
const enabled=Boolean(process.env.TEST_DATABASE_URL);
const pool=enabled?new Pool({connectionString:process.env.TEST_DATABASE_URL,max:15}):null;
test('simultaneous contractor claims yield exactly one winner and one acceptance history event',{skip:!enabled},async()=>{
 const client=await pool.connect();
 let requestId;
 try{
  await client.query('begin');
  const ids=await client.query("select c.user_id,c.trade,c.service_area from public.contractors c where c.approved group by c.user_id,c.trade,c.service_area having count(*)=1 limit 20");
  const pair=ids.rows.find(a=>ids.rows.some(b=>a.user_id!==b.user_id&&a.trade===b.trade&&a.service_area===b.service_area));
  if(!pair)throw Error('Seed two approved contractors with matching trade and service area');
  const others=ids.rows.filter(x=>x.trade===pair.trade&&x.service_area===pair.service_area&&x.user_id!==pair.user_id);
  const homeowner=await client.query("select user_id from public.memberships limit 1");
  if(!homeowner.rows.length)throw Error('Seed a homeowner membership');
  const created=await client.query("insert into public.repair_requests(user_id,trade,service_area,description,status) values($1,$2,$3,'concurrency test','open') returning id",[homeowner.rows[0].user_id,pair.trade,pair.service_area]);
  requestId=created.rows[0].id;
  await client.query('commit');
  const contenders=[pair.user_id,others[0].user_id];
  const results=await Promise.all(contenders.map(async id=>{
   const c=await pool.connect();try{return (await c.query('select public.claim_repair($1,$2) as claimed',[requestId,id])).rows[0].claimed}finally{c.release()}
  }));
  assert.equal(results.filter(Boolean).length,1);
  const rows=await pool.query("select * from public.contractor_assignment_history where request_id=$1 and action='accepted'",[requestId]);
  assert.equal(rows.rowCount,1);
  const winner=await pool.query('select contractor_id from public.repair_assignments where request_id=$1',[requestId]);
  assert.equal(winner.rowCount,1);
  const homeownerId=homeowner.rows[0].user_id;
  const outcomes=await Promise.allSettled([
   pool.query('select public.send_repair_message($1,$2,$3)',[requestId,homeownerId,'racing message']),
   pool.query('select public.reopen_repair($1,$2)',[requestId,winner.rows[0].contractor_id])
  ]);
  assert.equal(outcomes.length,2);
  const after=await pool.query('select * from public.repair_messages where request_id=$1',[requestId]);
  assert.equal(after.rowCount,0,'reopening must delete earlier messages even during race');
  await assert.rejects(pool.query('select * from public.read_repair_messages($1,$2,100)',[requestId,winner.rows[0].contractor_id]));
 }finally{
  if(requestId)await pool.query('delete from public.repair_requests where id=$1',[requestId]);
  client.release();
 }
});
process.on('beforeExit',()=>pool?.end());
