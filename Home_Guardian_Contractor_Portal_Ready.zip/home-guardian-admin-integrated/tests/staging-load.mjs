// Staging-only load probe: run with STAGING_URL and STAGING_BEARER_TOKEN.
// Does not simulate 1,500 simultaneous users: 1,500 iterations with bounded concurrency.
import assert from 'node:assert/strict';
const url=process.env.STAGING_URL,token=process.env.STAGING_BEARER_TOKEN;
if(!url||!token)throw Error('Set STAGING_URL and STAGING_BEARER_TOKEN for a disposable staging environment');
const total=1500, concurrency=30, latencies=[], errors=[];let index=0;
async function worker(){while(index<total){index++;const start=performance.now();try{const r=await fetch(new URL('/api/admin/overview',url),{headers:{Authorization:`Bearer ${token}`}});if(!r.ok)errors.push(r.status);else await r.json()}catch(e){errors.push(String(e))}latencies.push(performance.now()-start)}}
await Promise.all(Array.from({length:concurrency},worker));latencies.sort((a,b)=>a-b);
console.log(JSON.stringify({requests:total,concurrency,errors:errors.length,p50_ms:latencies[Math.floor(total*.5)],p95_ms:latencies[Math.floor(total*.95)],p99_ms:latencies[Math.floor(total*.99)]},null,2));
assert.equal(errors.length,0,'Staging probe encountered failures');
