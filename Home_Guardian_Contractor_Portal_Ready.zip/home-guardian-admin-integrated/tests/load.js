// Run: BASE_URL=https://your-domain TOKEN=... k6 run -e BASE_URL=$BASE_URL -e TOKEN=$TOKEN tests/load.js
// Requires a staging contractor account with approved status and seeded requests.
import http from 'k6/http';
import {check,sleep} from 'k6';
export const options={scenarios:{members:{executor:'ramping-vus',startVUs:0,stages:[{duration:'1m',target:50},{duration:'3m',target:150},{duration:'1m',target:0}]}},thresholds:{http_req_failed:['rate<0.01'],http_req_duration:['p(95)<1000']}};
export default function(){const r=http.get(`${__ENV.BASE_URL}/api/contractor/opportunities`,{headers:{Authorization:`Bearer ${__ENV.TOKEN}`}});check(r,{'response 200':x=>x.status===200});sleep(2);}
