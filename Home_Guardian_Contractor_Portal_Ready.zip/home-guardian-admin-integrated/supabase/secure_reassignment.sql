-- Run after schema.sql and exclusive_contractors.sql.
-- All changes to assignments and messages are serialized on the repair request row.
create table if not exists public.home_guardian_admins (
 user_id uuid primary key references auth.users(id) on delete cascade
);
create table if not exists public.contractor_alerts (
 id bigint generated always as identity primary key,
 contractor_id uuid not null references public.contractors(user_id),
 request_id bigint not null references public.repair_requests(id) on delete cascade,
 event_type text not null check (event_type in ('reopened')),
 created_at timestamptz not null default now(),
 read_at timestamptz,
 unique(contractor_id,request_id,event_type,created_at)
);
create index if not exists contractor_alerts_inbox_idx on public.contractor_alerts(contractor_id,created_at desc);
alter table public.home_guardian_admins enable row level security;
alter table public.contractor_alerts enable row level security;
-- Locking request rows makes claims, releases, and message inserts mutually exclusive.
create or replace function public.claim_repair(p_request_id bigint,p_contractor_id uuid)
returns boolean language plpgsql security definer set search_path=public as $$
declare r public.repair_requests%rowtype;
begin
 select * into r from public.repair_requests where id=p_request_id for update;
 if not found or r.status <> 'open' then return false; end if;
 if not exists(select 1 from public.contractors c where c.user_id=p_contractor_id and c.approved and c.trade=r.trade and c.service_area=r.service_area) then return false; end if;
 insert into public.repair_assignments(request_id,contractor_id) values(p_request_id,p_contractor_id) on conflict do nothing;
 if not found then return false; end if;
 update public.repair_requests set status='assigned' where id=p_request_id;
 return true;
end $$;
-- Contractor can decline their own job; an administrator may reopen any assignment.
-- The original contractor is excluded from this reopening notification batch.
create or replace function public.reopen_repair(p_request_id bigint,p_actor_id uuid)
returns integer language plpgsql security definer set search_path=public as $$
declare r public.repair_requests%rowtype; old_contractor uuid; n integer;
begin
 select * into r from public.repair_requests where id=p_request_id for update;
 if not found then raise exception 'Request not found'; end if;
 select contractor_id into old_contractor from public.repair_assignments where request_id=p_request_id;
 if old_contractor is null or r.status <> 'assigned' then raise exception 'Request not assigned'; end if;
 if p_actor_id <> old_contractor and not exists(select 1 from public.home_guardian_admins where user_id=p_actor_id) then raise exception 'Not authorized'; end if;
 -- Delete previous conversation so the next contractor cannot read old messages.
 delete from public.repair_messages where request_id=p_request_id;
 delete from public.repair_assignments where request_id=p_request_id;
 update public.repair_requests set status='open' where id=p_request_id;
 insert into public.contractor_alerts(contractor_id,request_id,event_type)
 select c.user_id,p_request_id,'reopened' from public.contractors c
 where c.approved and c.trade=r.trade and c.service_area=r.service_area and c.user_id<>old_contractor;
 get diagnostics n=row_count;
 return n;
end $$;
-- Message authorization and insert must happen inside the same row lock as reassignment.
create or replace function public.send_repair_message(p_request_id bigint,p_sender_id uuid,p_body text)
returns bigint language plpgsql security definer set search_path=public as $$
declare r public.repair_requests%rowtype; assigned uuid; message_id bigint;
begin
 if length(trim(coalesce(p_body,''))) not between 1 and 2000 then raise exception 'Invalid message'; end if;
 select * into r from public.repair_requests where id=p_request_id for update;
 if not found or r.status <> 'assigned' then raise exception 'Request unavailable'; end if;
 select contractor_id into assigned from public.repair_assignments where request_id=p_request_id;
 if assigned is null or (p_sender_id <> assigned and p_sender_id <> r.user_id) then raise exception 'Access denied'; end if;
 insert into public.repair_messages(request_id,sender_id,body) values(p_request_id,p_sender_id,trim(p_body)) returning id into message_id;
 return message_id;
end $$;
revoke all on function public.claim_repair(bigint,uuid) from public,anon,authenticated;
revoke all on function public.reopen_repair(bigint,uuid) from public,anon,authenticated;
revoke all on function public.send_repair_message(bigint,uuid,text) from public,anon,authenticated;
grant execute on function public.claim_repair(bigint,uuid) to service_role;
grant execute on function public.reopen_repair(bigint,uuid) to service_role;
grant execute on function public.send_repair_message(bigint,uuid,text) to service_role;
