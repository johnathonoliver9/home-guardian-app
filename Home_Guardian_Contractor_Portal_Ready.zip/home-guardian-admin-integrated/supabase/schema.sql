create table public.memberships (user_id uuid primary key references auth.users(id) on delete cascade, stripe_subscription_id text unique, status text not null default 'inactive', plan text check(plan in ('monthly','annual')), paid_through timestamptz, updated_at timestamptz default now());
create table public.homes (user_id uuid primary key references auth.users(id) on delete cascade, year_built int not null, hvac_type text not null, filter_last_changed date not null, heater_type text not null, heater_last_serviced date not null, gutters boolean not null);
create table public.maintenance_tasks (id bigint generated always as identity primary key, user_id uuid not null references auth.users(id) on delete cascade, code text not null, title text not null, frequency_days int not null, next_due date not null, instructions text not null, unique(user_id,code));
create table public.notifications (id bigint generated always as identity primary key, user_id uuid not null references auth.users(id) on delete cascade, task_id bigint not null references public.maintenance_tasks(id) on delete cascade, reminder_date date not null, title text not null, body text not null, created_at timestamptz default now(), read_at timestamptz, unique(task_id,reminder_date));
create table public.repair_requests (id bigint generated always as identity primary key, user_id uuid not null references auth.users(id) on delete cascade, trade text not null, description text not null, status text not null default 'open', created_at timestamptz default now());
-- Disable direct browser writes to protected tables. API uses server-only service role.
alter table public.memberships enable row level security;
alter table public.homes enable row level security;
alter table public.maintenance_tasks enable row level security;
alter table public.notifications enable row level security;
alter table public.repair_requests enable row level security;
-- No public policies: authenticated browser clients cannot read or mutate these tables directly.
