-- Run AFTER schema.sql. Atomic claim prevents double assignment even under concurrency.
create table if not exists public.contractors (
 user_id uuid primary key references auth.users(id) on delete cascade,
 approved boolean not null default false,
 trade text not null check(trade in ('plumbing','hvac','electrical','roofing','general')),
 service_area text not null,
 created_at timestamptz not null default now()
);
-- One active contractor per repair request, enforced by primary key.
create table if not exists public.repair_assignments (
 request_id bigint primary key references public.repair_requests(id) on delete cascade,
 contractor_id uuid not null references public.contractors(user_id),
 assigned_at timestamptz not null default now()
);
create table if not exists public.repair_messages (
 id bigint generated always as identity primary key,
 request_id bigint not null references public.repair_assignments(request_id) on delete cascade,
 sender_id uuid not null references auth.users(id),
 body text not null check(char_length(body) between 1 and 2000),
 created_at timestamptz not null default now()
);
-- Service area must be set when a homeowner creates a request. Existing requests
-- without service areas will not be offered until an admin fills it in.
alter table public.repair_requests add column if not exists service_area text;
create index if not exists repair_requests_open_trade_area_idx on public.repair_requests(trade,service_area,created_at) where status='open';
create index if not exists repair_messages_request_idx on public.repair_messages(request_id,created_at);
create index if not exists repair_assignments_contractor_idx on public.repair_assignments(contractor_id);
alter table public.contractors enable row level security;
alter table public.repair_assignments enable row level security;
alter table public.repair_messages enable row level security;
-- No browser access: use server endpoints with verified Supabase auth.
-- Only server role can call this function; a single INSERT ON CONFLICT is atomic.
create or replace function public.claim_repair(p_request_id bigint,p_contractor_id uuid)
returns boolean language plpgsql security definer set search_path=public as $$
declare v_claimed bigint;
begin
  insert into public.repair_assignments(request_id,contractor_id)
  select r.id, c.user_id from public.repair_requests r
  join public.contractors c on c.user_id=p_contractor_id
  where r.id=p_request_id and r.status='open' and c.approved
    and c.trade=r.trade and c.service_area=r.service_area
  on conflict(request_id) do nothing returning request_id into v_claimed;
  if v_claimed is null then return false; end if;
  update public.repair_requests set status='assigned' where id=p_request_id;
  return true;
end $$;
revoke all on function public.claim_repair(bigint,uuid) from public,anon,authenticated;
grant execute on function public.claim_repair(bigint,uuid) to service_role;
