-- Apply AFTER secure_reassignment.sql. Back up production data first.
create table if not exists public.contractor_assignment_history(
 id bigint generated always as identity primary key,
 request_id bigint not null references public.repair_requests(id) on delete cascade,
 contractor_id uuid not null references public.contractors(user_id),
 action text not null check(action in ('accepted','declined','admin_reopened')),
 actor_id uuid not null references auth.users(id),
 occurred_at timestamptz not null default now()
);
create index if not exists assignment_history_request_idx on public.contractor_assignment_history(request_id,occurred_at desc);
create table if not exists public.admin_audit_logs(
 id bigint generated always as identity primary key,
 actor_id uuid not null references auth.users(id),
 action text not null,
 target_type text not null,
 target_id text not null,
 details jsonb not null default '{}'::jsonb,
 occurred_at timestamptz not null default now()
);
create index if not exists audit_occurred_idx on public.admin_audit_logs(occurred_at desc);
create table if not exists public.notification_outbox(
 id bigint generated always as identity primary key,
 recipient_id uuid not null references auth.users(id),
 request_id bigint references public.repair_requests(id) on delete cascade,
 kind text not null,
 event_key text not null unique,
 email text,
 subject text not null,
 body text not null,
 status text not null default 'pending' check(status in ('pending','processing','sent','failed')),
 attempts int not null default 0,
 next_attempt_at timestamptz not null default now(),
 lease_until timestamptz,
 delivered_at timestamptz,
 last_error text,
 created_at timestamptz not null default now()
);
create index if not exists outbox_pending_idx on public.notification_outbox(status,next_attempt_at);
alter table public.contractor_assignment_history enable row level security;
alter table public.admin_audit_logs enable row level security;
alter table public.notification_outbox enable row level security;
-- Existing repair_messages is intentionally deleted on reassignment; protect read with the SAME lock.
create or replace function public.read_repair_messages(p_request_id bigint,p_reader_id uuid,p_limit int default 100)
returns table(id bigint,sender_id uuid,body text,created_at timestamptz)
language plpgsql security definer set search_path=public as $$
declare r public.repair_requests%rowtype; assigned uuid;
begin
 select * into r from public.repair_requests rr where rr.id=p_request_id for share;
 if not found or r.status<>'assigned' then raise exception 'Access denied'; end if;
 select a.contractor_id into assigned from public.repair_assignments a where a.request_id=p_request_id;
 if assigned is null or p_reader_id<>r.user_id and p_reader_id<>assigned then raise exception 'Access denied'; end if;
 return query select m.id,m.sender_id,m.body,m.created_at from public.repair_messages m
 where m.request_id=p_request_id order by m.created_at desc limit least(greatest(p_limit,1),100);
end $$;
-- Lock request row for all assignment transitions; history and alerts commit atomically.
create or replace function public.claim_repair(p_request_id bigint,p_contractor_id uuid)
returns boolean language plpgsql security definer set search_path=public as $$
declare r public.repair_requests%rowtype;
begin
 select * into r from public.repair_requests where id=p_request_id for update;
 if not found or r.status<>'open' then return false; end if;
 if not exists(select 1 from public.contractors c where c.user_id=p_contractor_id and c.approved and c.trade=r.trade and c.service_area=r.service_area) then return false; end if;
 insert into public.repair_assignments(request_id,contractor_id) values(p_request_id,p_contractor_id) on conflict do nothing;
 if not found then return false; end if;
 update public.repair_requests set status='assigned' where id=p_request_id;
 insert into public.contractor_assignment_history(request_id,contractor_id,action,actor_id)
 values(p_request_id,p_contractor_id,'accepted',p_contractor_id);
 return true;
end $$;
create or replace function public.reopen_repair(p_request_id bigint,p_actor_id uuid)
returns integer language plpgsql security definer set search_path=public as $$
declare r public.repair_requests%rowtype; old_contractor uuid; n integer; is_admin boolean;
begin
 select * into r from public.repair_requests where id=p_request_id for update;
 if not found or r.status<>'assigned' then raise exception 'Request unavailable'; end if;
 select contractor_id into old_contractor from public.repair_assignments where request_id=p_request_id;
 if old_contractor is null then raise exception 'Assignment missing'; end if;
 select exists(select 1 from public.home_guardian_admins where user_id=p_actor_id) into is_admin;
 if p_actor_id<>old_contractor and not is_admin then raise exception 'Not authorized'; end if;
 insert into public.contractor_assignment_history(request_id,contractor_id,action,actor_id)
 values(p_request_id,old_contractor,case when is_admin and p_actor_id<>old_contractor then 'admin_reopened' else 'declined' end,p_actor_id);
 if is_admin and p_actor_id<>old_contractor then
  insert into public.admin_audit_logs(actor_id,action,target_type,target_id,details)
  values(p_actor_id,'reopen_request','repair_request',p_request_id::text,jsonb_build_object('previous_contractor',old_contractor));
 end if;
 delete from public.repair_messages where request_id=p_request_id;
 delete from public.repair_assignments where request_id=p_request_id;
 update public.repair_requests set status='open' where id=p_request_id;
 -- No homeowner private details in these alerts; only the work order reference.
 insert into public.contractor_alerts(contractor_id,request_id,event_type)
 select c.user_id,p_request_id,'reopened' from public.contractors c
 where c.approved and c.trade=r.trade and c.service_area=r.service_area and c.user_id<>old_contractor;
 get diagnostics n=row_count;
 insert into public.notification_outbox(recipient_id,request_id,kind,event_key,subject,body)
 select c.user_id,p_request_id,'job_reopened',
 'job-reopened:'||p_request_id||':'||extract(epoch from clock_timestamp())::bigint||':'||c.user_id,
 'Home Guardian: job available','An eligible work order is available in your contractor dashboard.'
 from public.contractors c where c.approved and c.trade=r.trade and c.service_area=r.service_area and c.user_id<>old_contractor;
 return n;
end $$;
create or replace function public.set_contractor_approval(p_actor_id uuid,p_contractor_id uuid,p_approved boolean)
returns boolean language plpgsql security definer set search_path=public as $$
begin
 if not exists(select 1 from public.home_guardian_admins where user_id=p_actor_id) then raise exception 'Not authorized'; end if;
 update public.contractors set approved=p_approved where user_id=p_contractor_id;
 if not found then return false; end if;
 insert into public.admin_audit_logs(actor_id,action,target_type,target_id,details)
 values(p_actor_id,case when p_approved then 'approve_contractor' else 'suspend_contractor' end,
 'contractor',p_contractor_id::text,jsonb_build_object('approved',p_approved));
 return true;
end $$;
-- Queue claiming via SKIP LOCKED to allow parallel workers.
create or replace function public.lease_notification_batch(p_limit int default 50)
returns setof public.notification_outbox language plpgsql security definer set search_path=public as $$
begin
 return query with selected as (
  select o.id from public.notification_outbox o
  where ((o.status='pending' and o.next_attempt_at<=now())
  or (o.status='processing' and o.lease_until<now()))
  and o.attempts<8
  order by o.created_at for update skip locked limit least(greatest(p_limit,1),100)
 ), updated as (
  update public.notification_outbox o set status='processing',attempts=o.attempts+1,lease_until=now()+interval '2 minutes'
  from selected s where o.id=s.id returning o.*
 ) select * from updated;
end $$;
-- Restrict all privileged functions to server-side service role.
revoke all on function public.read_repair_messages(bigint,uuid,int) from public,anon,authenticated;
revoke all on function public.claim_repair(bigint,uuid) from public,anon,authenticated;
revoke all on function public.reopen_repair(bigint,uuid) from public,anon,authenticated;
revoke all on function public.set_contractor_approval(uuid,uuid,boolean) from public,anon,authenticated;
revoke all on function public.lease_notification_batch(int) from public,anon,authenticated;
grant execute on function public.read_repair_messages(bigint,uuid,int) to service_role;
grant execute on function public.claim_repair(bigint,uuid) to service_role;
grant execute on function public.reopen_repair(bigint,uuid) to service_role;
grant execute on function public.set_contractor_approval(uuid,uuid,boolean) to service_role;
grant execute on function public.lease_notification_batch(int) to service_role;
